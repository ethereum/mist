
module.exports = {
    name: 'Mist',
    version: '0.0.1'
};